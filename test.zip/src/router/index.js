import Vue from 'vue'
import Router from 'vue-router'
import Idx from '@/components/Idx'
import Mint from 'mint-ui'
Vue.use(Router)
Vue.use(Mint)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Idx',
      component: Idx
    }
  ]
})
