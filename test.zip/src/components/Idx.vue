<template>
  <div class="idx">
		<div class="idxheader">
			<div class="nav">
				<div class="navleft">
					<div class="xiaoxi"></div>
				</div>
				<div class="navbutton">
					<ul>
						<li>期货</li>
						<li>原油</li>
					</ul>
				</div>
				<div class="navsearch">
					<img slot="icot" src="../assets/nav_icon_sousuo_default.svg" />
				</div>
			</div>
		</div>
		<div class="idxmain">
			
		</div>
    <div class="idxfooter">
			<div class="footer">
				<mt-tabbar v-model="selected">
					<mt-tab-item id="外卖">
						<img slot="icon" src="../assets/tab_icon_home_default.svg">
						外卖
					</mt-tab-item>
					<mt-tab-item id="订单">
						<img slot="icon" src="../assets/tab_icon_hangqingan_default.svg">
						订单
					</mt-tab-item>
					<mt-tab-item id="发现">
						<img slot="icon" src="../assets/tab_icon_kuaixunan_default.svg">
						发现
					</mt-tab-item>
					<mt-tab-item id="我的">
						<img slot="icon" src="../assets/tab_icon_me_weidianliang_default.svg">
						我的
					</mt-tab-item>
				</mt-tabbar>
			</div>
		</div>
  </div>
</template>
<script>
	import { Tabbar, TabItem } from 'mint-ui';
export default {
  name: 'Idx',
	components:{Tabbar, TabItem},
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>
<style lang="less" scoped="scoped">
	@import '../../styles/main.less';
	// @import '../../styles/sass/idx.scss';
	li{
		list-style: none;
	}
.idx{
		.idxheader{
			.w(375);
			.h(44);
			background:rgba(255,255,255,1);
			.nav{
				.margin(8,8,8,8);
				height: 100%;
				display: flex;
				justify-content: space-between;
				.navleft{
					.w(19);
					height: 100%;
					.xiaoxi{
						.h(19);
						.w(19);
						display: inline-block;
						background: url('../assets/nav_icon_xiaoxi_default.svg') no-repeat;
					}
				}
				.navbutton{
					ul{
						.lh(44);
						.w(120);
						.h(28);
						background:rgba(255,255,255,1);
						.bdradius(14);
						border:1px solid rgba(120,181,204,1);
						display:flex;
						justify-content: center;
						li{
							.w(60);
							.h(28);
							background:rgba(120,181,204,1);
							.bdradius(14);
							border:1px solid rgba(120,181,204,1);
							flex: 1;
							text-align: center;
							.lh(28);
							.fs(15);
							font-family:PingFangSC-Medium;
							font-weight:500;
							color:rgba(175,181,187,1);
						}
					}
				}
			}
		}
	}
</style>
